cat 3.reputation2.cypher  | cypher-shell -u neo4j -p Re91na00!!  -a bolt://localhost:7687   -d neo4j

